#!__*__coding:utf-8__*__

f=open("d:\\SHN\\test01.txt","w")
f.write("hello world. 안녕하세요\n한줄띄고 룰루랄라")
f.write("안녕2")
f.write("\r\n")
#f.write("\t")
#f.writeline("안녕하숑")

f.close()


a=True
cnt=1
while a:
    print("hello world")
    print("hello world2")
    cnt=cnt+1
    print("cnt is ",str(cnt))
    if cnt>10:
        a=False
print("x")
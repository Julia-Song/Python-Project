#!__*__coding:utf-8__*__

def help_screen():
    print("File: Input File name")
    print("Movie: Get Movie data")
    print("Help: Displays this help screen")
    print("Quit: Exits the program")

if __name__=="__main":      #내가 메인으로 실행되면 밑에꺼를 해라 (모듈로 이 파일을 실행하면 아래꺼는 실행안됨)
    help_screen()